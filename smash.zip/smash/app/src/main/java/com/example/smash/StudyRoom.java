package com.example.smash;

public class StudyRoom {
}
